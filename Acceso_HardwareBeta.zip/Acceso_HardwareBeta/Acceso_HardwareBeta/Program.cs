﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.Win32;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net.NetworkInformation;
using Acceso_Hardware2;

namespace HardwareySO
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            while(i == 0)
            {
                int op = Menu();
                if(op==7)
                {
                    i = op;
                }
                switch (op)
                {
                    case 1:
                        string serial = "";
                        serial = Acceso_Hardware2.informacion.SerialNumber();
                        Console.WriteLine(serial);
                        serial = Acceso_Hardware2.informacion.SerialCD();
                        Console.WriteLine(serial);
                        break;
                    case 2:
                        string[] unidades = Environment.GetLogicalDrives();
                        Console.WriteLine("Unidades = " + string.Join(" ", unidades));
                        break;
                    case 3:
                        Console.WriteLine("Numero de procesadores = " + Environment.ProcessorCount);
                        string ram = "";
                        ram = Acceso_Hardware2.informacion.RAM();
                        Console.WriteLine(ram);
                        break;
                    case 4:
                        String Mac = "";
                        Mac = Acceso_Hardware2.informacion.macAddress();
                        Console.WriteLine(Mac);
                        break;
                    case 5:
                        leer();
                        editar();
                        break;

                    case 6:
                        string proc = "";
                        List<string> Proceso = new List<string>();
                        Proceso = Acceso_Hardware2.informacion.Procesos();
                        foreach (string p in Proceso)
                        {
                            Console.WriteLine(p);
                        }
                        Console.WriteLine("Que proceso desea matar, ingrese el nombre");
                        proc = Console.ReadLine();
                        Acceso_Hardware2.informacion.MatarProcesos(proc);
                        Console.WriteLine("Proceso eliminado");
                        break;
                    default:
                        Console.WriteLine("Ingrese una opcion valida");
                        break;
                }

            }    
        }
        static int Menu()
        {
            Console.WriteLine("Por favor seleccione una opción\n");
            Console.WriteLine("\t.-Leer el nùmero serie del Disco Duro / CD / DVD.");
            Console.WriteLine("\t.-¿Cúantas unidades de disco tiene?");
            Console.WriteLine("\t.-Balance general del sistema : Procesadores, RAM, NIC");
            Console.WriteLine("\t.-Obtener MAC Address.");
            Console.WriteLine("\t.-Acceso al Registro del Sistema. Crear Clave / Leer clave / Borrar clave / Modificar clave.");
            Console.WriteLine("\t.-Obtener los procesos activos / matar procesos.");
            Console.WriteLine("\t.-Salir");
            int opc = int.Parse(Console.ReadLine());
            return opc;
        }

        public static void leer()
        {
            Console.WriteLine("Ingrese la ruta del registro a leer");
            string Source = Console.ReadLine();
            Console.WriteLine("Ingrese la llave del registro a leer");
            string Key = Console.ReadLine();
            Console.WriteLine("el valor que se encontro en la ruta " + Source + " : fue: " + ReadRegistryValue(Source, Key));
        }
        public static void editar()
        {
            Console.WriteLine("Ingrese la ruta del registro a editar");
            string Source = Console.ReadLine();
            Console.WriteLine("Ingrese la llave del registro a editar");
            string KeyName = Console.ReadLine();
            Console.WriteLine("Ingresa el valor de la llave:" + KeyName);
            string value = Console.ReadLine();
            setRegistryValue(Source, KeyName, value);

        }
        private static void setRegistryValue(string source, string keyName, string value)
        {
            Registry.SetValue(source, keyName, value);
        }
        private static string ReadRegistryValue(string Source, string key)
        {
            return Registry.GetValue(Source, key, "NO FOUND").ToString();
        }
    }



}

